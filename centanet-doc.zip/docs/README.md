---
home: true
heroImage: /assets/word.svg
heroText: CENTANET-前端项目指南
tagline: 中原官网 & House730相关项目文档
actionText: 阅读文档 →
actionLink: /guide/index/
---