# 文档概览
<br>

## 概览

本文档整理包括官网前端规范，找房官网、香港house730前端相关项目详细资料，  
包括项目对接人员、框架结构、项目注意事项、以及部署流程等。   
核心内容均整理至此文档，其他补充文档参考[语雀【中原地产】知识库](https://www.yuque.com/books/share/ceaf75b6-c212-4cf9-9a8b-4dc29c6984fa)。  

**补充文档地址：**  
<https://www.yuque.com/books/share/ceaf75b6-c212-4cf9-9a8b-4dc29c6984fa>   

<br><br>



## 文档更新

**文档对应git地址：**  
<http://gitlab.centaline.com.cn/centnet-group/centanet/tools/centanet-doc>  

**更新日志**  

| 日期       | 修改人员 | 备注                                  |
| ---------- | -------- | ------------------------------------- |
| 2021.01.15 | 黄宽     | 创建                                  |
| 2021.02.19 | 黄宽     | 更新官网前端规范，更新HOUSE730-VR文档 |
| 2021.02.23 | 黄宽     | 内容补充完善                                  |
| 2021.02.24 | 何宇菲   | 新增PMS-PC部分文档                    |
（若文档有较大修改，请在以上表格更新日志，并迁入至上访GIT地址的mater分支）







<br><br>

## 包含项目


### 1.官网移动站(<https://m.sz.centanet.com>)
中原官网移动端站点,面向外网客户, 除【香港】【澳门】【上海】外,所有城市官网移动站均使用此套应用


### 2.官网用户中心(<https://passpoet.centanet.com>)
中原官网用户中心 , 响应式站点 , 除【香港】【澳门】【上海】外 , 所有城市官网用户中心PC/M站均使用此套应用



### 3.小程序(经纪人端)微聊 / WEB(客户端)微聊
提供给经纪人和客户之间在线聊天咨询的应用，包括经纪人端小程序与PC/M客户端(h5)<br />


### 4.其他工具类(<https://esf.centanet.com/tools/模块名称>)
官网通用工具类页面，包括房贷计算器、在线委托、用户轨迹、二手房新房VR看房、大湾区活动页、在线签约等子程序



### 5.官网移动站SEO程序
原官网移动站程序改造成nuxt.js框架服务端渲染, 搜索引擎爬虫特征的UA访问时 指向此程序。


### 6.House730官网(<https://m.house730.com/>)
类似于大陆地区的安居客、房天下的在线找房平台,仅供香港地区使用。


### 7.House730用户中心(<https://m.house730.com/my/>)
提供给用户发布、管理房源、房源收藏、留言,以及账户充值等功能。<br />


### 8.House730-PMS移动站(<https://pms.house730.com/m/>)
提供给外部代理公司使用,用于发布、管理盘源的系统(后期将逐步停止维护,主体迁移至app端)。


### 9.House730-PMS-PC站(<https://pms.house730.com/>)
提供给外部代理公司使用,用于发布、管理盘源的PC端系统。<br />


### 10.房友圈部分H5页面(<http://fangyouquan.com/>)
针对中小中介提供的房源代理分佣平台，详细文档参考语雀。


<br><br>

## 涉及API服务

### 1.【官网】二手房核心服务
**对接人员：李涛**  
仅对内访问, 官网二手房服务,包含租房、小区、经纪人等以及其他通用功能（成交等）, 大部分数据源都来自于核心服务提供, 前端人员不直接调用此接口。

### 2.【官网】二手房mobileapi服务
**对接人员：钟金龙、白金强**  
基于二手房核心服务的封装,提供对外访问,功能属于核心服务的子集,部分敏感接口未开放。<br />
**深圳：**<https://apisz.centanet.com/lion/java/json/reply/>  
**其他城市：**<https://mobileapi.centanet.com/v6/java/json/reply/>   
**文档地址：**<http://mobileapi-test.centaline.com.cn/swagger-ui.html>


### 3.【官网】新房服务
**对接人员：邹渊**  
新房相关服务接口  
**深圳：**<https://apisz.centanet.com/lion/java/json/reply/>    
**其他城市：**<https://mobileapi.centanet.com/lion/java/json/reply/>   
**文档地址:** <https://mobileapi.centanet.com/lion/java/swagger-ui.html>


### 4.【官网】公共服务（bizcom）
**对接人员：邹渊、邓天天**  
400电话、微聊等相关公共服务  
**全国：**<https://mobileapi.centanet.com/bizcom/json/reply/>  
**文档地址：**<http://api-testweb.centaline.com.cn/bizcom/swagger-ui.html>


### 4.【官网】直聊重构API服务（Talk）
**对接人员：李松松**  
适用于云信版本微聊API   
**全国：**<https://talk.centanet.com/im>   
**文档地址：**<http://10.4.18.194:7050/index.html?urls.primaryName=talk%20api%20v5>


### 5.【官网】用户中心服务（passport）
**对接人员：白金强(JAVA)、王传林(.NET)**  
用户相关服务,例如用户进行房源收藏、预约看房、接收消息通知等,目前已重构为java版本  
**全国：**<https://mobileapi.centanet.com/passport/v6/java/json/reply/>  
**文档地址：**<http://api-testpassport.centaline.com.cn/swagger-ui.html#/>


### 6.【HOUSE730】HOUSE730官网API服务
**对接人员：周辉、**  
香港HOUSE730项目 官网及730用户中心文档    
**香港：**<https://api.house730.com/>    
**文档地址：**<http://uatapi.house730.com.cn/swagger/index.html>


### 7.【730PMS】PMS放盘站API服务
**对接人员：周辉、赵闹闹**  
香港HOUSE730项目 PMS放盘站API服务  
**香港：**<https://pmsapi.house730.com/>   
**文档地址：**<http://uatpmsapi.house730.com.cn/swagger/index.html>

<br><br>

## 服务调用通用规则
**所有请求需在参数里添加cityen 和 platform参数。**  
- **cityen**： 城市简拼,例如"bj"、"sz",便于服务端区分来自哪个城市的业务请求  
- **platform**： 接口调用平台,M站统一传参数"wap"
